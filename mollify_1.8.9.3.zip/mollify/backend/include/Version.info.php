<?php
	$VERSION = "1.8.9.3";
	$REVISION = 1653;
?>