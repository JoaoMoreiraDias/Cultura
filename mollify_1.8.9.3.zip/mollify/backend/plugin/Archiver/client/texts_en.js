(function(){ mollify.texts.add('en', {

plugin_archiver_extractAction: "Extract",
plugin_archiver_extractFolderAlreadyExistsTitle: "Extract",
plugin_archiver_extractFolderAlreadyExistsMessage: "Folder already exists with the archive name, do you want to overwrite it?",

plugin_archiver_compressAction: "Compress",
plugin_archiver_compressFileAlreadyExistsTitle: "Compress",
plugin_archiver_compressFileAlreadyExistsMessage: "File already exists with the compressed archive name, do you want to overwrite it?"

})})();