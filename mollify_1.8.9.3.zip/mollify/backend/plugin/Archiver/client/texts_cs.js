(function(){ mollify.texts.add('cs', {

plugin_archiver_extractAction: "Rozbalit",
plugin_archiver_extractFolderAlreadyExistsTitle: "Rozbalit",
plugin_archiver_extractFolderAlreadyExistsMessage: "Složka se jménem archivu už existuje, má se přepsat?"

})})();
