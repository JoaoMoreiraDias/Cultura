<?php
	$REGISTRATION_NOTIFICATION_SUBJECT = "Mollify registration";
	$REGISTRATION_NOTIFICATION_MESSAGE = "Thank you %name% for registering to Mollify.\n\nComplete your registration by opening following confirmation link: %link%\n\nThis notification was sent to %email%";
?>