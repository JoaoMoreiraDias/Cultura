(function(){ mollify.texts.add('en', {
commentsDialogTitle: "Comments",
commentsDialogNoComments: "No comments",
commentsDialogAddButton: "Add",
commentsDetailsCount: "Comments",
commentsDialogRemoveComment: "Remove"
})})();