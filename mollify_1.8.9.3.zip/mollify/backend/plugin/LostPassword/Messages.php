<?php
	$RESET_PASSWORD_NOTIFICATION_SUBJECT = "Mollify password reset";
	$RESET_PASSWORD_NOTIFICATION_MESSAGE = "Your Mollify password has been reset. Your new password is: %password%\n\nThis notification was sent to %email%";
?>