<html>
	<head>
		<title>Upload Complete</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
		<link rel="stylesheet" href="<?php echo $RESOURCE_URL ?>style.css">
	</head>
	<body>
		<div id="message">Uploading complete</div>
	</body>
</html>