
   _____ _                 _ _  __       
  / ____(_)               | (_)/ _|      
 | (___  _ _ __ ___  _ __ | |_| |_ _   _ 
  \___ \| | '_ ` _ \| '_ \| | |  _| | | |
  ____) | | | | | | | |_) | | | | | |_| |
 |_____/|_|_| |_| |_| .__/|_|_|_|  \__, |
                    | |             __/ |
                    |_|            |___/ 


Simplify - Theme modification for Mollify by Mike T.


### INSTALLATION ###

Installing the theme is easy & straight forward:

1. Copy simpliffy folder into client/themes folder.
2. Change the css path in your index.html to be as: <link rel="stylesheet" href="client/themes/simplify/style_min.css">
   (notice: also include IE stylesheets with conditionals, found in the package)
3. Save your index.html and voila, you're done.


### STICKY FOOTER ###

Additionaly if you want sticky footer, open index.html in the package to see the code and markup.


### MOLLIFY VERSION ###

This theme is modified for version 1.8.9.2.


### SUPPORTED BROWSERS ###

Currently the supported browsers for this theme are:

- Chrome 15+
- Firefox 10+
- Opera
- Safari
- Internet Explorer 9
- Internet Explorer 8 (has few bugs tho)

If i find some spare time soon, i'll make fixes for older IE's also.
Better yet, use updated and some new age browser :)

Mike T.

-----------------------------------------------------------------------------------------------------------------
Disclaimer: The theme and files are provided as is, without any guarantee and you should use it at your own risk.